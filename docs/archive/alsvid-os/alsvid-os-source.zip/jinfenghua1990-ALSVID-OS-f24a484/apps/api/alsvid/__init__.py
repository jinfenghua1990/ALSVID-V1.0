"""ALSVID standalone application package."""
